"""Personal investment portfolio tracker with interactive Streamlit dashboard."""

__version__ = "0.1.0"

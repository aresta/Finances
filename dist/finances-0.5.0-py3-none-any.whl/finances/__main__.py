"""Allow running the app via ``python -m finances``."""

from finances.app import main

main()
